// Bola
let xbola = 700/2;
let ybola = 200;
let zdiametro_bola = 20;
let raio = zdiametro_bola/2;

let velocidade_bola = 6;
let yvelocidade_bola = 6;

//Bibliotecas

let impacto = false;

// Raquete 
let xret = 5;
let yret = 400/2;
let zdiametro_ret = 12;
let ret_comprimento = 70;
let ret_borda = 50;

//Raquete_ia

let xreti = 680;
let yreti = 400/2;
let y_vel_reti;
let ia_fisica;
let erro_ia = 0;

//Placar
let pontoA = 0;
let pontoB = 0;

//Som

let rets;
let ponto;
let trilha;

function setup() {
  createCanvas(700, 400);
  trilha.loop();
}

function draw() {
  background(0);
  bola_imagem();
  bola_movimento();
  bola_comportamento();
  raquete_imagem(xret,yret);
  raquete_imagem(xreti,yreti);
  raquete_controle();
  raquete_comportamento(xret,yret);
  raquete_comportamento(xreti,yreti);
  placar();
  //raquete_especial();
  raquete_IA();
  //multiplayer();
  //bolaPresa();
  }

function bola_imagem(){
  stroke(166, 49, 24);
  circle (xbola,ybola,zdiametro_bola);
  
}

function bola_movimento(){
  xbola += velocidade_bola;
  ybola += yvelocidade_bola;
}

function bola_comportamento(){
  if (xbola + raio > width || xbola - raio < 0){
    velocidade_bola *= -1;
  }
  if (ybola + raio > height || ybola - raio < 0){
     yvelocidade_bola *= -1;
  }

}

function raquete_imagem(x,y){
  rect(x,y,zdiametro_ret,ret_comprimento,ret_borda);
  
}

function raquete_controle(){
  
  if (keyIsDown(DOWN_ARROW)){
     yret += 10;
  }
 if (keyIsDown(UP_ARROW)){
     yret -= 10;
  }
  yret = constrain(yret,0,330);
}

function raquete_comportamento(x,y){
  impacto = collideRectCircle(x, y, zdiametro_ret, ret_comprimento, xbola, ybola, raio);
  
  if(impacto){
    velocidade_bola *= -1;
    rets.play();
  }
  
}
  
function raquete_especial(){
  if (keyIsDown (LEFT_ARROW)){
      velocidade_bola *= 10;
      yvelocidade_bola *= 0;
        }
}

function raquete_IA(){
  y_vel_reti = ybola - yreti - ret_comprimento/2 - erro_ia ;
  yreti += y_vel_reti;
  yreti = constrain(yreti,0,330);
 
  if(pontoB == 3){
    erro_ia = 35;
  }
  if(pontoA == pontoB || pontoB<8){
    erro_ia = 0;
  }
  
} 

function placar(){
  textAlign (CENTER);
  textSize(30);
  stroke(255);
  fill(color(166, 49, 24));
  rect(558/2,10,50,40,20);
  rect(750/2,10,50,40,20);
  fill(500);
  text(pontoA,610/2,39);
  text(pontoB,800/2,39);
  
  if (xbola > 690){
      pontoA += 1;
    ponto.play();
    xbola=700/2;
      }
  if (xbola < 10){
    pontoB +=1;
    ponto.play();
    xbola=700/2;
    
  }
}

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  rets = loadSound("raquetada.mp3");
  
}

function multiplayer(){
  if (keyIsDown(83)){
     yreti += 10;
  }
 if (keyIsDown(87)){
     yreti -= 10;
  }
  yreti = constrain(yreti,0,330);
}

function bolaPresa(){
    if (xbola > 690){
    xbola = 665;
    }
    if (xbola < 0){
      xbola = 10
    }
}


  
